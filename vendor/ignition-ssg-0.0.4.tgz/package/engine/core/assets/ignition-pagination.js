/**
 * Ignition Pagination — client-side pagination via the COMMON reactivity runtime.
 *
 * Reuses the shared runtime instead of re-implementing it:
 *   - templates live in the common registry (window.ignition.registerTemplate)
 *   - helpers are the single source from helpers.js (registered by the boot)
 *   - the dataset lands in reactive state, so bindings and blocks can consume it
 *
 * Failure contract (EF-19): the engine never draws error UI. On a failed data
 * or template load it logs to the console (developer channel), sets
 * state.__pagination.error = { message, url } and dispatches 'ignition:pageError'
 * on the container. A later successful load or page switch clears the flag.
 * Presenting it — a plate, a toast, nothing — is the developer's call.
 *
 * Debugging / containers added after load: window.ignitionPagination.init()
 * rescans the DOM. Already-initialized containers are skipped; a container
 * whose init failed is retried.
 */
(function () {
  'use strict';

  const DATA_ATTR = 'data-ignition-pagination';
  const initialized = new WeakSet();

  function getConfig(container) {
    try {
      return JSON.parse(container.dataset.ignitionPagination);
    } catch (e) {
      return null;
    }
  }

  function failState(runtime, container, err, url) {
    const detail = {
      message: (err && err.message) || String(err),
      url: url
    };
    try {
      const state = runtime.state;
      state.__pagination = state.__pagination || {};
      state.__pagination.error = detail;
    } catch (e) {
      // State is best-effort; the event and the console log still fire.
    }
    container.dispatchEvent(new CustomEvent('ignition:pageError', { detail: { error: detail } }));
  }

  async function loadPageTemplate(config, runtime) {
    // If this template is already in the common registry (e.g. it is also a
    // reactive block template), reuse it — no duplicate compile.
    const existing = runtime.getTemplate(config.templateUrl);
    if (existing) return existing;

    let url = config.templateUrl;
    let res = await fetch(url);
    if (!res.ok && res.status === 404) {
      url = url.replace(/\/page\.hbs$/, '/pagination.hbs');
      res = await fetch(url);
    }
    if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
    const source = await res.text();

    // Register through the common runtime so subsequent work reuses it.
    runtime.registerTemplate(config.templateUrl, function (data) {
      return Handlebars.compile(source)(data);
    });
    return runtime.getTemplate(config.templateUrl);
  }

  function collectionPage(state, config, page) {
    const collection = (state && state[config.collection]) || [];
    const start = (page - 1) * config.perPage;
    return collection.slice(start, start + config.perPage);
  }

  function totalPages(state, config) {
    const collection = (state && state[config.collection]) || [];
    return Math.max(1, Math.ceil(collection.length / config.perPage));
  }

  function paginationData(config, state, page) {
    const total = totalPages(state, config);
    return {
      currentPage: page,
      totalPages: total,
      hasNext: page < total,
      hasPrev: page > 1,
      nextPage: page + 1,
      prevPage: page - 1
    };
  }

  async function initContainer(container, runtime, config) {
    // Load the full dataset through the common runtime and expose the page
    // slice as reactive state, so blocks depending on it re-render.
    const state = runtime.state;
    if (!state[config.collection]) {
      const dataset = await runtime.fetchJson(config.dataUrl);
      state[config.collection] = dataset[config.collection] || [];
    }
    state.__pagination = state.__pagination || {
      currentPage: config.currentPage,
      config: config
    };

    const template = await loadPageTemplate(config, runtime);

    // A load that succeeds clears a previously raised error flag.
    if (state.__pagination.error) state.__pagination.error = null;

    function render(page) {
      const items = collectionPage(state, config, page);
      const html = template({
        items,
        pagination: paginationData(config, state, page)
      });
      runtime.hydrate(container, html);

      // State catches up only after the DOM actually switched, so a failed
      // render never leaves the model describing a page that is not shown.
      state.__pagination.currentPage = page;
      if (state.__pagination.error) state.__pagination.error = null;
      container.dispatchEvent(new CustomEvent('ignition:pageChange', { detail: { page } }));
    }

    container.addEventListener('click', function (e) {
      const link = e.target.closest('[data-page]');
      if (!link) return;
      e.preventDefault();
      const page = parseInt(link.dataset.page, 10);
      const current = state.__pagination.currentPage;
      if (!Number.isFinite(page) || page === current || page < 1 || page > totalPages(state, config)) {
        return;
      }
      try {
        render(page);
        history.pushState({ page }, `Page ${page}`, link.href);
      } catch (err) {
        console.error('Ignition pagination render failed:', err);
        failState(runtime, container, err, config.templateUrl);
      }
    });
  }

  function init() {
    const runtime = window.ignition;
    if (!runtime) return;

    document.querySelectorAll(`[${DATA_ATTR}]`).forEach(function (container) {
      if (initialized.has(container)) return;
      initialized.add(container);

      const config = getConfig(container);
      initContainer(container, runtime, config).catch(function (err) {
        initialized.delete(container);
        console.error('Ignition pagination failed:', err);
        failState(runtime, container, err, config && config.dataUrl);
      });
    });
  }

  window.ignitionPagination = { init: init };

  document.addEventListener('DOMContentLoaded', init);
})();
