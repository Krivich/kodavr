// core/renderer.js
import path from 'path';
import fs from 'fs/promises'; // <-- Adding import
import { fileURLToPath } from 'url';
import Handlebars from 'handlebars'; // <-- EXPLICIT IMPORT
import logger from '../utils/logger.js';
import {
    safeMkdir,
    atomicWrite,
    safeReadJson
} from '../utils/fs.js';
import {
    detectPaginationInTemplate,
    registerCorePartials,
    registerHelpers
} from './handlebars.js';
import { paginateCollection, preparePageData } from './pagination.js';
import { resetManifest, getManifest } from './helpers.js';
import { deriveInitialState, needsRuntime } from '../utils/deriveInitialState.js';
import { fineCoverage, blockSignals } from './fineRegistry.js';
import { analyzeTemplate, applyAutobindings, applyProjections, collectEachPaths, collectRootSignals } from './compiler.js';
import config from '../config/default.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function buildDataUrl(layout, dataset) {
  return `/data/${layout}/${dataset}.json`;
}

function injectDataPreload(html, layout, dataset, live = false) {
  if (!live) return html;
  const dataUrl = buildDataUrl(layout, dataset);
  const link = `<link rel="preload" href="${dataUrl}" as="fetch" crossorigin="anonymous">`;
  const headClose = html.indexOf('</head>');
  if (headClose === -1) return link + html;
  return html.slice(0, headClose) + link + html.slice(headClose);
}

// EF-10: auto-block wrappers are engine-owned DOM between the author's markup
// and its content. `display: contents` takes the wrapper out of the layout box
// tree, so authored flex/grid containers behave exactly as if the block were
// inline — a pinned/flex UI is not broken by an invisible growing div.
// Escape hatch: ship your own `<style data-ignition-css>` in the template and
// the engine does not inject anything — your cascade rules apply. The hatch is
// checked against the TEMPLATE SOURCES, never the rendered html: rendered
// content may quote this constant (a tool output showing the engine's own
// source) and would otherwise suppress the reset, leaving auto-block wrappers
// display:block — the author's flex/grid layout breaks and the page scrolls
// instead of the stream.
const BLOCK_DISPLAY_RESET = '<style data-ignition-css>[data-ignition-block]{display:contents}</style>';

function injectBlockDisplayReset(html, authorReset = false) {
  if (authorReset) return html;
  if (!html.includes('data-ignition-block')) return html;
  const headClose = html.indexOf('</head>');
  if (headClose === -1) return html + BLOCK_DISPLAY_RESET;
  return html.slice(0, headClose) + BLOCK_DISPLAY_RESET + html.slice(headClose);
}

/**
 * Escape a JSON string for safe inlining into a <script> tag.
 */
function jsonSafe(obj) {
  return JSON.stringify(obj)
    .replace(/</g, '\\u003c')
    .replace(/>/g, '\\u003e')
    .replace(/&/g, '\\u0026')
    .replace(/'/g, '\\u0027');
}

/**
 * Auto-inject the client-side boot: initial state, registered templates and the
 * reactivity runtime. This lets the developer declare reactivity declaratively
 * (pagination, bindings, a controller) without writing runtime <script> tags by
 * hand. Templates that already embed the scripts are left untouched.
 *
 * The "already embedded" check runs on the TEMPLATE SOURCES (layout + partials),
 * never on the rendered html: rendered content may legitimately quote this very
 * file or the boot tags (a tool output showing the engine's own source, a docs
 * page, a code sample) — a substring scan over the html would read that as a
 * hand-written boot and silently skip the injection, leaving the page dead
 * (window.ignition undefined).
 *
 * @param {string} html - Rendered page HTML
 * @param {{initialData: object, templates: object}} payload - Boot data
 * @param {boolean} gate - Whether the page needs the runtime at all
 * @param {boolean} isPagination - Whether the page is a real pagination page
 * @param {{boot: boolean, pagination: boolean}} bootPresent - Which boot tags the template sources already carry
 */
function injectClientBoot(html, payload, gate, isPagination = false, bootPresent = { boot: false, pagination: false, css: false }) {
  if (!gate) return html;

  const insert = (h, tags) => {
    const bodyClose = h.lastIndexOf('</body>');
    const block = '\n' + tags.join('\n') + '\n';
    if (bodyClose === -1) return h + block;
    return h.slice(0, bodyClose) + block + h.slice(bodyClose);
  };

  // Reactive boot (state + templates + runtime). Live pages re-render blocks
  // client-side, which needs the Handlebars compiler — provided self-hosted by
  // the engine so the developer never writes a manual <script> tag.
  if (payload && !bootPresent.boot) {
    html = insert(html, [
      `<script src="/assets/handlebars.min.js"></script>`,
      `<script>window.__IGNITION_INITIAL_DATA__ = ${jsonSafe(payload.initialData)};</script>`,
      `<script>window.__IGNITION_TEMPLATES__ = ${jsonSafe(payload.templates)};</script>`,
      `<script src="/assets/ignition-runtime.js"></script>`
    ]);
  }

  // System mini-controller: a real pagination page needs its script too.
  // (Same source-based gate as the boot above — see the header comment.)
  if (isPagination && !bootPresent.pagination) {
    html = insert(html, [`<script src="/assets/ignition-pagination.js" defer></script>`]);
  }

  return html;
}

/**
 * Which engine-owned markup the template sources already carry. The scan
 * covers the layout source and every registered partial source — author-
 * written markup, immune to whatever the page DATA later renders into the
 * html. Every "already present" decision must go through this, not through
 * substring scans of the rendered page.
 *
 * @param {string} layoutSource - Raw layout template source
 * @param {Object<string, string>} templateSources - Registered partial sources
 * @returns {{boot: boolean, pagination: boolean, css: boolean}}
 */
function engineMarkupInSources(layoutSource, templateSources) {
  const scan = layoutSource + '\n' + Object.values(templateSources || {}).join('\n');
  return {
    boot: /<script[^>]*ignition-runtime\.js/.test(scan) || /__IGNITION_INITIAL_DATA__/.test(scan),
    pagination: /<script[^>]*ignition-pagination\.js/.test(scan),
    css: /data-ignition-css/.test(scan),
    controller: /<script[^>]*src="[^"]*assets\/controllers\//.test(scan)
  };
}

/**
 * Whether an external controller exists for this layout/dataset. Presence of a
 * controller means "someone can change the model" → the page needs the runtime.
 */
async function hasController(layout, dataset) {
  const controllersDir = config.source.controllers;
  const candidates = [
    path.join(controllersDir, `${layout}.js`),
    path.join(controllersDir, layout, `${dataset}.js`)
  ];
  for (const c of candidates) {
    try {
      await fs.access(c);
      return true;
    } catch (_) { /* next */ }
  }
  return false;
}

/**
 * Auto-inject the external page controller: the "someone who changes the model".
 * The renderer looks for input/controllers/{layout}.js (or {layout}/{dataset}.js),
 * copies it into output/assets/controllers/ and links it on the page. A controller
 * is an explicit declaration that the page is alive → it also forces the runtime.
 *
 * @param {string} html   - Rendered page HTML
 * @param {string} layout - Layout name
 * @param {string} dataset- Dataset name
 * @param {boolean} authorTag - The template sources already link a controller
 */
async function injectController(html, layout, dataset, outputDir, authorTag = false) {
  const controllersDir = config.source.controllers;
  const candidates = [
    path.join(controllersDir, `${layout}.js`),
    path.join(controllersDir, layout, `${dataset}.js`)
  ];

  let found = null;
  for (const c of candidates) {
    try {
      await fs.access(c);
      found = c;
      break;
    } catch (_) { /* not found, try next */ }
  }
  if (!found || authorTag) return html;

  const destDir = path.join(config.output.assets, 'controllers');
  const dest = path.join(destDir, path.basename(found));
  await safeMkdir(destDir);
  await fs.copyFile(found, dest);

  const tag = `<script src="/assets/controllers/${path.basename(dest)}"></script>`;

  const bodyClose = html.lastIndexOf('</body>');
  if (bodyClose === -1) return html + '\n' + tag;
  return html.slice(0, bodyClose) + '\n' + tag + '\n' + html.slice(bodyClose);
}

/**
 * Wrap partial content with reflection attributes for auto-blocks.
 * 
 * @param {string} content - Partial template content
 * @param {string} blockName - Block name (layout/partial)
 * @param {string} dataPath - Data path for the block
 * @param {string} depends - Dependencies for the block
 * @returns {string} - Wrapped template content
 */
function wrapPartialWithReflection(content, blockName, dataPath, depends, fine = null) {
  // Use the existing {{#block}} helper to wrap the partial.
  // `autoblock=1` tells the helper to render the inline raw body with the
  // current context (and record the manifest slice from the root), instead of
  // resolving the partial by name again (which is THIS same wrapper and would
  // recurse). Explicit {{#block}} helpers in layouts don't set this flag.
  // `fine` lists depends paths fully covered by @p stickers - the runtime
  // block skips re-renders for leaf-only changes under them.
  const fineAttr = fine && fine.size ? ` fine="${[...fine].join(', ')}"` : '';
  return `{{#block name="${blockName}" data="${dataPath}" depends="${depends}"${fineAttr} autoblock=1}}${content}{{/block}}`;
}

// Initialize Handlebars
await registerCorePartials();
registerHelpers();

/**
 * Per-template-context cache. All downstream derivations from a layout's raw
 * source — AST analysis, pagination config, autobinding/projection transforms
 * and the compiled Handlebars function — depend only on the template content,
 * NOT on the data. Recomputing them for every page wastes the two most
 * expensive steps (Handlebars.parse + Handlebars.compile). We key by the raw
 * source string so any edit to a layout invalidates exactly that entry.
 *
 * @type {Map<string, {analysis: object, paginationConfig: object,
 *        transformed: string, projected: string, compile: Function}>}
 */
const templateContextCache = new Map();

function getTemplateContext(templateContent, templateName = 'template') {
  let cached = templateContextCache.get(templateContent);
  if (cached) return cached;
  const analysis = analyzeTemplate(templateContent);
  const paginationConfig = detectPaginationInTemplate(templateContent);
  const transformed = applyAutobindings(templateContent);
  const projected = applyProjections(transformed, {
    onDiag: (items) => warnLostFineGrained(templateName, items),
  });
  cached = {
    analysis,
    paginationConfig,
    transformed,
    projected,
    compile: Handlebars.compile(projected)
  };
  templateContextCache.set(templateContent, cached);
  return cached;
}

export function _clearTemplateCache() { templateContextCache.clear(); }

// Build-time diagnostics: a list that lost fine-grained updates degrades to a
// full block re-render on every cell change - tell the author why. Every
// reason carries a stable IGN-FG-* code, searchable in REACTIVITY.md §5.
// EF-11: partial re-registration (watch mode re-registers on every template
// edit) must not repeat the same line — one emission per (template, collection,
// codes) per process, with the code as the first token so it greps cleanly.
const emittedDiagnostics = new Set();

export function _clearDiagnostics() {
  emittedDiagnostics.clear();
}

function warnLostFineGrained(templateName, items) {
  for (const { collection, reasons } of items) {
    const codes = reasons.map((r) => r.code).join(',');
    const key = `${templateName}|${collection}|${codes}`;
    if (emittedDiagnostics.has(key)) continue;
    emittedDiagnostics.add(key);
    const detail = reasons.map((r) => `[${r.code}] ${r.text}`).join('; ');
    logger.warn(
      `[${codes}] ${templateName}: list "${collection}" re-renders its block on every cell change — ${detail}. ` +
      `Fix recipes: REACTIVITY.md §5, "Fixing fine-grained warnings".`
    );
  }
}

export async function renderTemplate(templatePath, data, outputDir, dataset, layout) {
    try {
        // 1. Read template
        const templateContent = await fs.readFile(templatePath, 'utf8');

        // 2-6. Analyze, transform and compile — cached by template content
        const ctx = getTemplateContext(templateContent, path.basename(templatePath, '.hbs'));
        const { analysis, paginationConfig, compile: template } = ctx;

        // 4. Read and register ALL partials from templates (also collect raw
        //    sources before Handlebars compiles them). Result is cached and
        //    only refreshed when the templates directory changes.
        const templateSources = await registerAllTemplatePartials(config.source.templates, analysis);

        // 6. Process pagination
        // Every "already present" decision (boot scripts, pagination script,
        // author's own reset css, controller tag) scans the AUTHOR SOURCES —
        // layout + partials — never the rendered html: page content may quote
        // any of these strings (tool outputs showing engine sources, docs,
        // code samples) and must not steer the engine. One scan, one shape,
        // passed through both render paths.
        const markup = engineMarkupInSources(templateContent, templateSources);
        if (paginationConfig.enabled) {
            await handlePagination(
                paginationConfig,
                template,
                data,
                outputDir,
                dataset,
                layout,
                templateSources,
                markup
            );
        } else {
            // Regular rendering
            const { layout: _l, dataset: _d, ...pureData } = data;
            resetManifest();
            // Per-render nonce on the substitution placeholders: the payload
            // markers travel through template DATA, so an honest template that
            // writes {{{initialData}}} / {{{manifest}}} / {{{templates}}} gets
            // the real JSON — while rendered page content that merely QUOTES
            // these literals (a tool output showing the engine's own source,
            // a docs snippet) must never match. A static literal would turn
            // any such quote into a multi-hundred-kilobyte JSON substitution
            // inside the page body (work-flow incident 2026-09-06: one widget
            // quoting this file inflated the SSR page to ~8.5 MB and — via the
            // same quote in the boot-guard scan — suppressed the runtime
            // injection entirely).
            const nonce = Math.random().toString(36).slice(2) + Date.now().toString(36);
            const phInitialData = `IGNITION_INITIAL_DATA_PLACEHOLDER__${nonce}__`;
            const phManifest = `IGNITION_MANIFEST_PLACEHOLDER__${nonce}__`;
            const phTemplates = `IGNITION_TEMPLATES_PLACEHOLDER__${nonce}__`;
            const html = template({
                ...data,
                layout,
                dataset,
                initialData: phInitialData,
                manifest: phManifest,
                templates: phTemplates
            });
            
            // Inject reflection attributes for auto-blocks
            let finalHtml = html;
            
            // v2: an external controller is "someone who can change the model".
            // It may read arbitrary dataset branches, so when a controller is
            // present the full dataset is inlined (REACTIVITY §7) and the page
            // is live (runtime + preload injected).
            const liveController = await hasController(layout, dataset);

            const renderedManifest = jsonSafe(getManifest());
            const templatesJson = jsonSafe(templateSources);

            // Compute the derived client state once (was computed twice — once
            // for inlining, once for the boot payload — with identical inputs).
            // Placeholders in the html carry no data-ignition-* markers, so the
            // extraction result is the same whether run before or after the
            // substitution below.
            const initialData = deriveInitialState(finalHtml, pureData, analysis, liveController);
            const derivedInitialData = jsonSafe(initialData);

            finalHtml = finalHtml
                .replaceAll(phInitialData, derivedInitialData)
                .replaceAll(phManifest, renderedManifest)
                .replaceAll(phTemplates, templatesJson);

            // v2: preload the full dataset only for live (interactive) pages —
            // a page that no one can change doesn't need the data fetched early.
            const liveRuntime = needsRuntime(finalHtml, analysis);
            const live = liveRuntime || liveController;
            logger.debug(`[ignition] Page ${dataset}.html — liveness: ${live ? 'live → runtime+preload injected' : 'static → runtime omitted'} (detected runtime: ${liveRuntime}, external controller: ${liveController})`);
            finalHtml = injectDataPreload(finalHtml, layout, dataset, live);
            // v2: auto-inject the runtime when the page is reactive, so the
            // developer does not hand-write the runtime <script> tags.
            finalHtml = injectClientBoot(finalHtml, {
                initialData,
                templates: templateSources
            }, live, paginationConfig.enabled, markup);
            // External controller (explicit "live page" declaration).
            finalHtml = await injectController(finalHtml, layout, dataset, outputDir, markup.controller);
            finalHtml = injectBlockDisplayReset(finalHtml, markup.css);
            const outputPath = path.join(outputDir, `${dataset}.html`);
            await safeMkdir(path.dirname(outputPath));
            await atomicWrite(outputPath, finalHtml);
            logger.info(`✅ Rendered single page: ${dataset}.html`);
        }

        // 7. Copy CSR template (if exists)
        if (paginationConfig.enabled) {
            await copyCsrTemplate(layout, paginationConfig.template);
        }

        return true;
    } catch (err) {
        logger.error(`❌ Failed to render template: ${templatePath}`, {
            error: err.message,
            stack: err.stack
        });
        throw err;
    }
}

let autoBlockCache = new Map();

/**
 * Compute a cheap signature for the templates tree: the sorted list of every
 * .hbs file's name + mtime + size. Stat calls are metadata-only I/O, far cheaper
 * than re-reading + transforming + re-registering every partial on each render.
 * @returns {Promise<string>}
 */
async function templatesSignature(templatesDir) {
  const entries = [];
  const walk = async (dir, prefix) => {
    let list;
    try {
      list = await fs.readdir(dir, { withFileTypes: true });
    } catch (err) {
      if (err.code === 'ENOENT') return;
      throw err;
    }
    for (const e of list) {
      const full = path.join(dir, e.name);
      if (e.isDirectory()) {
        await walk(full, `${prefix}${e.name}/`);
      } else if (e.isFile() && e.name.endsWith('.hbs')) {
        const s = await fs.stat(full);
        entries.push(`${prefix}${e.name}:${s.mtimeMs}:${s.size}`);
      }
    }
  };
  await walk(templatesDir, '');
  return entries.sort().join('|');
}

const partialCache = new Map();

/**
 * Compute the set of auto-block partials deterministically across EVERY layout.
 * A partial used as `{{> some/partial <data>}}` in any layout becomes an
 * auto-block. Everything is decided globally (scanned once and cached) so that
 * concurrent rendering tasks all register the same partials the same way — the
 * per-layout analysis based decision is racy on the shared global Handlebars.
 *
 * @returns {Promise<Map<string, {dataPath: string, depends: string}>>}
 */
async function detectAutoBlocks(templatesDir, signature) {
    if (autoBlockCache.has(signature)) return autoBlockCache.get(signature);
    const map = new Map();
    // Explicit {{#block name=X}} calls in layouts, by their raw name — used to
    // warn when an author double-wraps an auto-block partial (the auto-block
    // already wraps itself). Keyed: rawName -> layout that calls it.
    const blockWrapCalls = new Map();
    const templateDirs = await fs.readdir(templatesDir, { withFileTypes: true });
    for (const entry of templateDirs) {
        if (!entry.isFile() || !entry.name.endsWith('.hbs')) continue;
        const layoutName = path.basename(entry.name, '.hbs');
        const src = await fs.readFile(path.join(templatesDir, entry.name), 'utf8');
        const a = analyzeTemplate(src);
        if (a.hasNoblock) continue;
        for (const p of a.partials) {
            if (!map.has(p.partialName)) {
                map.set(p.partialName, { dataPath: p.dataPath, depends: p.depends });
            }
        }
        // Raw explicit {{#block name=...}} helpers (autoblock wrappers have
        // autoblock=1 and are filtered out by name extraction).
        for (const m of src.match(/\{\{#block\s+name="([^"]+)"\s*[^}]*\}\}/g) || []) {
            const rawName = /name="([^"]+)"/.exec(m)[1];
            if (!blockWrapCalls.has(rawName)) blockWrapCalls.set(rawName, layoutName);
        }
    }
    autoBlockCache.set(signature, { map, blockWrapCalls });
    return { map, blockWrapCalls };
}

async function registerAllTemplatePartials(templatesDir, analysis = null) {
    const signature = await templatesSignature(templatesDir);
    // Fast path: templates unchanged → reuse cached sources + already-registered
    // partials, avoiding the full read/transform/register pass on every render.
    // The promise itself is cached so concurrent render tasks (queue
    // concurrency > 1) share one registration pass instead of duplicating it
    // (and duplicating its build-time warnings).
    const cached = partialCache.get(signature);
    if (cached) return cached;
    const inFlight = registerAllTemplatePartialsUncached(templatesDir, signature);
    partialCache.set(signature, inFlight);
    return inFlight;
}

async function registerAllTemplatePartialsUncached(templatesDir, signature) {
    const sources = {};
    try {
        const { map: autoBlockMap, blockWrapCalls } = await detectAutoBlocks(templatesDir, signature);
        const autoBlocks = autoBlockMap;
        const templateDirs = await fs.readdir(templatesDir, { withFileTypes: true });

        for (const dir of templateDirs) {
            if (dir.isDirectory()) {
                const partialsDir = path.join(templatesDir, dir.name);
                const files = await fs.readdir(partialsDir, { withFileTypes: true });

                for (const file of files) {
                    if (file.isFile() && file.name.endsWith('.hbs')) {
                        const partialName = path.basename(file.name, '.hbs');
                        const fullName = `${dir.name}/${partialName}`;
                        const content = await fs.readFile(path.join(partialsDir, file.name), 'utf8');
                        // Autobindings + row-scoped @p projections. Partials get
                        // scopedOnly: their call-site context may be shifted, so
                        // top-level stickers would resolve against wrong paths.
                        let fine = null;
                        const transformedContent = applyProjections(applyAutobindings(content), {
                            scopedOnly: true,
                            onFine: (s) => { fine = s; },
                            onDiag: (items) => warnLostFineGrained(fullName, items),
                        });

                        // Deterministic auto-block decision (global, not per-task)
                        const autoBlock = autoBlocks.get(fullName);

                        if (autoBlock) {
                            // Row-scoped {{#each <rootPath>}} (fine coverage
                            // non-empty) resolves its @p stickers from the STATE
                            // ROOT, so the block MUST NOT slice context: keep
                            // root by dropping dataPath. Its depends are the
                            // covered collections so structural changes (push/
                            // splice on that path) re-render the block, while
                            // leaf changes patch cells via stickers.
                            const rootProjected = Boolean(fine && fine.size);
                            const dataPath = rootProjected ? '' : autoBlock.dataPath;
                            let depends = rootProjected
                                ? [...fine].join(', ')
                                : autoBlock.depends;

                            // Container partial: the each body is a nested
                            // partial call, so there is no fine coverage and
                            // autoBlock.depends is usually empty. The root
                            // {{#each}} collections are the only thing this
                            // block can subscribe to — without them a push
                            // into the list would never re-render anything.
                            if (!rootProjected) {
                                const eachPaths = collectEachPaths(content)
                                    .filter((p) => !String(depends || '')
                                        .split(',')
                                        .map((s) => s.trim())
                                        .includes(p));
                                if (eachPaths.length) {
                                    depends = [depends, ...eachPaths].filter(Boolean).join(', ');
                                }
                            }

                            // Predictable error: a root-projected partial called
                            // with a context param (`{{> list products}}`) shifts
                            // `this`, so `{{#each products}}` renders nothing and
                            // the block comes out empty. Tell the author.
                            if (rootProjected && autoBlock.dataPath) {
                                logger.warn(
                                    `⚠️ ${fullName}: row-scoped {{#each}} resolves from the state root — ` +
                                    `calling this partial with a context param ({{> ${fullName} ${autoBlock.dataPath}}}) ` +
                                    `shifts the context and renders an empty block. ` +
                                    `Call it without a param: {{> ${fullName}}}. [IGN-FG-PARAM]`
                                );
                            }

                            // Predictable error: an explicit {{#block name=...}} in
                            // a layout that resolves to THIS auto-block partial
                            // double-wraps it — the runtime binds the same region
                            // twice (double subscriptions, double patches). Tell the
                            // author to just use the plain partial call.
                            const rawTail = fullName.includes('/') ? fullName.split('/').pop() : null;
                            let blockOwner;
                            let rawNameUsed;
                            if (blockWrapCalls.has(fullName)) {
                                blockOwner = blockWrapCalls.get(fullName);
                                rawNameUsed = fullName;
                            } else if (rawTail) {
                                const owner = blockWrapCalls.get(rawTail);
                                if (owner === fullName.split('/')[0]) {
                                    blockOwner = owner;
                                    rawNameUsed = rawTail;
                                }
                            }
                            if (blockOwner) {
                                logger.warn(
                                    `⚠️ ${fullName}: layout "${blockOwner}" wraps this auto-block partial in an ` +
                                    `explicit {{#block name="${rawNameUsed}"}} — the partial is already a block ` +
                                    `on its own, so this double-wraps it (double bindings, double re-renders). ` +
                                    `Remove the {{#block}} and use the plain call: {{> ${fullName}}}. [IGN-FG-BLOCK]`
                                );
                            }

                            // Wrap partial with reflection attributes for SSR block rendering
                            const wrappedContent = wrapPartialWithReflection(
                                transformedContent,
                                fullName,
                                dataPath,
                                depends,
                                fine
                            );
                            Handlebars.registerPartial(fullName, wrappedContent);
                            // Client re-render uses the raw partial source (without the SSR wrapper)
                            sources[fullName] = transformedContent;
                            logger.debug(`✅ Registered auto-block partial: ${fullName}`);
                        } else {
                            Handlebars.registerPartial(fullName, transformedContent);
                            sources[fullName] = transformedContent;
                            logger.debug(`✅ Registered partial: ${fullName}`);
                        }
                        // Expose the partial's fine-grained coverage to the {{#block}}
                        // helper - explicit block calls in layouts resolve the partial
                        // by name and stamp data-ignition-fine from here.
                        if (fine && fine.size) {
                            fineCoverage.set(fullName, fine);
                        } else {
                            fineCoverage.delete(fullName);
                        }
                        // Expose the partial's root branch signals ({{#if X}} at
                        // root context) to the {{#block}} helper - they merge
                        // into the block's depends so widget-level flags like
                        // `metrics.loading` re-render the block when they flip.
                        const signals = collectRootSignals(content);
                        if (signals.length) {
                            blockSignals.set(fullName, signals);
                        } else {
                            blockSignals.delete(fullName);
                        }
                    }
                }
            }
        }
    } catch (err) {
        if (err.code !== 'ENOENT') {
            logger.error('❌ Failed to register template partials', { error: err.message });
        }
    }
    return sources;
}

async function copyCsrTemplate(layout, pageTemplate) {
    if (!pageTemplate || /[.]{2}/.test(String(pageTemplate)) || /[^a-zA-Z0-9\-_]/.test(String(pageTemplate))) {
        logger.warn(`⚠️ Invalid pageTemplate value for CSR copy: ${pageTemplate}`);
        return false;
    }
    const sourcePath = path.join(config.source.templates, layout, `${pageTemplate}.hbs`);
    const outputPath = path.join(config.output.templates, layout, `${pageTemplate}.hbs`);

    try {
        await fs.access(sourcePath);
        await safeMkdir(path.dirname(outputPath));
        await fs.copyFile(sourcePath, outputPath);

        logger.info(`✅ Copied CSR template: ${layout}.hbs`);
        return true;
    } catch (err) {
        if (err.code === 'ENOENT') {
            logger.warn(`⚠️ CSR template not found: ${sourcePath}`);
            // Create a stub for development
            await safeMkdir(path.dirname(outputPath));
            await fs.writeFile(outputPath, '<div class="pagination-placeholder">Pagination template not found</div>');
            return false;
        }
        throw err;
    }
}

/**
 * Process pagination with correct context
 */
async function handlePagination(config, template, data, outputDir, dataset, layout, templateSources, bootPresent = { boot: false, pagination: false, css: false }) {
    const pages = paginateCollection(data, config.collection, config.perPage);

    for (const page of pages) {
        // Form config for client-side pagination
        const paginationConfigForClient = {
            collection: config.collection,
            perPage: config.perPage,
            currentPage: page.pageNumber,
            totalPages: page.totalPages,
            dataUrl: `/data/${layout}/${dataset}.json`, // Correct path to data
            templateUrl: `/templates/${config.fullTemplatePath}.hbs` // Full path to template!
        };

        const pageData = {
            ...data,
            layout,
            dataset,
            pagination: preparePageData(data, page, page.pageNumber).pagination,
            paginationConfig: paginationConfigForClient // Pass to template
        };

        const html = template(pageData);
        let pageFile = injectDataPreload(html, layout, dataset, true);
        // v2: pagination is a system mini-controller — it changes the page in
        // the model, so it needs the runtime. Auto-inject full dataset (so the
        // client can slice the whole collection) + registered templates.
        let pageHtml = injectClientBoot(pageFile, {
            initialData: data,
            templates: templateSources
        }, true, true, bootPresent);
        // External controller (explicit "live page" declaration).
        pageHtml = await injectController(pageHtml, layout, dataset, outputDir, bootPresent.controller);
        pageHtml = injectBlockDisplayReset(pageHtml, bootPresent.css);
        const pagePath = path.join(outputDir, dataset, 'page', `${page.pageNumber}.html`);
        await safeMkdir(path.dirname(pagePath));
        await atomicWrite(pagePath, pageHtml);
    }
}

// core/renderer.js
/**
 * Generate client artifacts (data for CSR)
 * @param {string} dataPath - Path to source JSON file
 * @param {string} layout - Template name (catalog)
 * @param {string} dataset - Dataset name (books)
 */
export async function generateClientArtifacts(dataPath, layout, dataset) {
    try {
        // 1. Read data
        const dataContent = await fs.readFile(dataPath, 'utf8');

        // 2. Form paths using CORRECT parameters
        const outputDataDir = path.join(config.output.data, layout);
        const outputDataPath = path.join(outputDataDir, `${dataset}.json`);

        // 3. Create directories
        await safeMkdir(outputDataDir);

        // 4. Save data with formatting (skip rewrite if the target already
        //    contains identical bytes — avoids needless disk churn in watch mode)
        const parsedData = JSON.parse(dataContent);
        const formattedData = JSON.stringify(parsedData, null, 2);
        let unchanged = false;
        try {
            const existing = await fs.readFile(outputDataPath, 'utf8');
            unchanged = existing === formattedData;
        } catch (_) { /* target missing → must write */ }
        if (!unchanged) {
            await atomicWrite(outputDataPath, formattedData);
        }

        logger.info(`✅ Generated client data for ${layout}/${dataset}.json`);

        return true;
    } catch (err) {
        logger.error(`❌ Failed to generate client artifacts for ${layout}/${dataset}`, {
            error: err.message,
            stack: err.stack,
            dataPath,
            layout,
            dataset
        });
        throw err;
    }
}

export { parseHandlebarsParams } from '../utils/parseParams.js';